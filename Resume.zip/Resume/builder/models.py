from django.conf import settings
from django.db import models


class Profile(models.Model):
	user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
	full_name = models.CharField(max_length=255)
	title = models.CharField(max_length=255, blank=True)
	summary = models.TextField(blank=True)
	phone = models.CharField(max_length=50, blank=True)
	location = models.CharField(max_length=255, blank=True)
	website = models.URLField(blank=True)
	avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)

	def __str__(self):
		return self.full_name or self.user.username


class Resume(models.Model):
	owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="resumes")
	title = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return f"{self.title} ({self.owner})"


class ResumeVersion(models.Model):
	resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name="versions")
	version_number = models.PositiveIntegerField()
	created_at = models.DateTimeField(auto_now_add=True)
	content_html = models.TextField()

	class Meta:
		unique_together = ("resume", "version_number")
		ordering = ["-version_number"]

	def __str__(self):
		return f"{self.resume.title} v{self.version_number}"


class Education(models.Model):
	resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name="educations")
	school = models.CharField(max_length=255)
	degree = models.CharField(max_length=255, blank=True)
	field_of_study = models.CharField(max_length=255, blank=True)
	start_date = models.DateField(null=True, blank=True)
	end_date = models.DateField(null=True, blank=True)
	description = models.TextField(blank=True)
	order = models.PositiveIntegerField(default=0)

	class Meta:
		ordering = ["order", "-start_date"]


class Experience(models.Model):
	resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name="experiences")
	company = models.CharField(max_length=255)
	role = models.CharField(max_length=255)
	start_date = models.DateField(null=True, blank=True)
	end_date = models.DateField(null=True, blank=True)
	description = models.TextField(blank=True)
	order = models.PositiveIntegerField(default=0)

	class Meta:
		ordering = ["order", "-start_date"]


class Skill(models.Model):
	resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name="skills")
	name = models.CharField(max_length=100)
	proficiency = models.CharField(max_length=100, blank=True)
	order = models.PositiveIntegerField(default=0)

	class Meta:
		ordering = ["order", "name"]
