from django.contrib import admin
from .models import Profile, Resume, ResumeVersion, Education, Experience, Skill


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
	list_display = ("user", "full_name", "title")


class EducationInline(admin.TabularInline):
	model = Education
	extra = 0


class ExperienceInline(admin.TabularInline):
	model = Experience
	extra = 0


class SkillInline(admin.TabularInline):
	model = Skill
	extra = 0


@admin.register(Resume)
class ResumeAdmin(admin.ModelAdmin):
	list_display = ("title", "owner", "updated_at")
	inlines = [EducationInline, ExperienceInline, SkillInline]


@admin.register(ResumeVersion)
class ResumeVersionAdmin(admin.ModelAdmin):
	list_display = ("resume", "version_number", "created_at")


@admin.register(Education)
class EducationAdmin(admin.ModelAdmin):
	list_display = ("resume", "school", "degree", "start_date", "end_date")


@admin.register(Experience)
class ExperienceAdmin(admin.ModelAdmin):
	list_display = ("resume", "company", "role", "start_date", "end_date")


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
	list_display = ("resume", "name", "proficiency")
