from django.urls import path
from . import views

urlpatterns = [
	path("", views.dashboard_view, name="dashboard"),
	path("profile/edit/", views.profile_edit_view, name="profile_edit"),
	path("resume/create/", views.resume_create_view, name="resume_create"),
	path("resume/<int:pk>/", views.resume_detail_view, name="resume_detail"),
	path("resume/<int:pk>/edit/", views.resume_edit_view, name="resume_edit"),
	path("resume/<int:pk>/delete/", views.resume_delete_view, name="resume_delete"),
	path("resume/<int:pk>/version/new/", views.resume_version_create_view, name="resume_version_create"),
	path("version/<int:version_id>/pdf/", views.resume_version_pdf_view, name="resume_version_pdf"),
]
