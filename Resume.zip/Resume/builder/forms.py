from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile, Resume, Education, Experience, Skill


class SignUpForm(UserCreationForm):
	email = forms.EmailField(required=True)
	full_name = forms.CharField(max_length=255)
	title = forms.CharField(max_length=255, required=False)

	class Meta:
		model = User
		fields = ("username", "email", "full_name", "title", "password1", "password2")


class ProfileForm(forms.ModelForm):
	class Meta:
		model = Profile
		fields = ["full_name", "title", "summary", "phone", "location", "website", "avatar"]


class ResumeForm(forms.ModelForm):
	class Meta:
		model = Resume
		fields = ["title"]


class EducationForm(forms.ModelForm):
	class Meta:
		model = Education
		fields = ["school", "degree", "field_of_study", "start_date", "end_date", "description"]
		widgets = {
			'start_date': forms.DateInput(attrs={'type': 'date'}),
			'end_date': forms.DateInput(attrs={'type': 'date'}),
			'description': forms.Textarea(attrs={'rows': 3}),
		}


class ExperienceForm(forms.ModelForm):
	class Meta:
		model = Experience
		fields = ["company", "role", "start_date", "end_date", "description"]
		widgets = {
			'start_date': forms.DateInput(attrs={'type': 'date'}),
			'end_date': forms.DateInput(attrs={'type': 'date'}),
			'description': forms.Textarea(attrs={'rows': 3}),
		}


class SkillForm(forms.ModelForm):
	class Meta:
		model = Skill
		fields = ["name", "proficiency"]
