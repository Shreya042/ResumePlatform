from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from io import BytesIO

from .forms import SignUpForm, ResumeForm, EducationForm, ExperienceForm, SkillForm, ProfileForm
from .models import Profile, Resume, ResumeVersion, Education, Experience, Skill


def signup_view(request):
	if request.method == "POST":
		form = SignUpForm(request.POST)
		if form.is_valid():
			user = form.save(commit=False)
			user.email = form.cleaned_data["email"]
			user.save()
			Profile.objects.create(
				user=user,
				full_name=form.cleaned_data["full_name"],
				title=form.cleaned_data.get("title", ""),
			)
			login(request, user)
			return redirect("dashboard")
	else:
		form = SignUpForm()
	return render(request, "builder/signup.html", {"form": form})


@login_required
def dashboard_view(request):
	resumes = Resume.objects.filter(owner=request.user).order_by("-updated_at")
	return render(request, "builder/dashboard.html", {"resumes": resumes})


@login_required
def resume_create_view(request):
	if request.method == "POST":
		form = ResumeForm(request.POST)
		if form.is_valid():
			resume = form.save(commit=False)
			resume.owner = request.user
			resume.save()
			return redirect("resume_edit", pk=resume.pk)
	else:
		form = ResumeForm()
	return render(request, "builder/resume_create.html", {"form": form})


@login_required
def resume_detail_view(request, pk):
	resume = get_object_or_404(Resume, pk=pk, owner=request.user)
	versions = resume.versions.all()
	educations = resume.educations.all()
	experiences = resume.experiences.all()
	skills = resume.skills.all()
	return render(
		request,
		"builder/resume_detail.html",
		{"resume": resume, "versions": versions, "educations": educations, "experiences": experiences, "skills": skills},
	)


@login_required
def resume_edit_view(request, pk):
	resume = get_object_or_404(Resume, pk=pk, owner=request.user)
	if request.method == "POST":
		resume_form = ResumeForm(request.POST, instance=resume)
		edu_form = EducationForm(request.POST)
		exp_form = ExperienceForm(request.POST)
		skill_form = SkillForm(request.POST)
		
		if "save_resume" in request.POST and resume_form.is_valid():
			resume_form.save()
			return redirect("resume_detail", pk=resume.pk)
			
		if "add_education" in request.POST and edu_form.is_valid():
			edu = edu_form.save(commit=False)
			edu.resume = resume
			# Set order to be the next available number
			edu.order = resume.educations.count() + 1
			edu.save()
			return redirect("resume_edit", pk=resume.pk)
			
		if "add_experience" in request.POST and exp_form.is_valid():
			exp = exp_form.save(commit=False)
			exp.resume = resume
			# Set order to be the next available number
			exp.order = resume.experiences.count() + 1
			exp.save()
			return redirect("resume_edit", pk=resume.pk)
			
		if "add_skill" in request.POST and skill_form.is_valid():
			sk = skill_form.save(commit=False)
			sk.resume = resume
			# Set order to be the next available number
			sk.order = resume.skills.count() + 1
			sk.save()
			return redirect("resume_edit", pk=resume.pk)
	else:
		resume_form = ResumeForm(instance=resume)
		edu_form = EducationForm()
		exp_form = ExperienceForm()
		skill_form = SkillForm()
		
	return render(
		request,
		"builder/resume_edit.html",
		{
			"resume": resume,
			"resume_form": resume_form,
			"edu_form": edu_form,
			"exp_form": exp_form,
			"skill_form": skill_form,
			"educations": resume.educations.all(),
			"experiences": resume.experiences.all(),
			"skills": resume.skills.all(),
		},
	)


@login_required
def resume_delete_view(request, pk):
	resume = get_object_or_404(Resume, pk=pk, owner=request.user)
	if request.method == "POST":
		resume.delete()
		return redirect("dashboard")
	return render(request, "builder/resume_delete_confirm.html", {"resume": resume})


@login_required
def resume_version_create_view(request, pk):
	resume = get_object_or_404(Resume, pk=pk, owner=request.user)
	content_html = render_to_string("builder/resume_pdf.html", {"resume": resume})
	latest = resume.versions.first()
	next_version = (latest.version_number + 1) if latest else 1
	ResumeVersion.objects.create(resume=resume, version_number=next_version, content_html=content_html)
	return redirect("resume_detail", pk=resume.pk)


@login_required
def resume_version_pdf_view(request, version_id):
	version = get_object_or_404(ResumeVersion, id=version_id, resume__owner=request.user)
	result = BytesIO()
	pdf = pisa.CreatePDF(src=version.content_html, dest=result)
	if pdf.err:
		return HttpResponse("Error generating PDF", status=500)
	response = HttpResponse(result.getvalue(), content_type="application/pdf")
	response["Content-Disposition"] = f"attachment; filename=resume_v{version.version_number}.pdf"
	return response


@login_required
def profile_edit_view(request):
	profile, created = Profile.objects.get_or_create(user=request.user)
	if request.method == "POST":
		form = ProfileForm(request.POST, request.FILES, instance=profile)
		if form.is_valid():
			form.save()
			return redirect("dashboard")
	else:
		form = ProfileForm(instance=profile)
	return render(request, "builder/profile_edit.html", {"form": form, "profile": profile})
